#!/bin/bash
BIN_FILE=$(readlink -f $0)
WORK_DIR=$(dirname $(dirname $BIN_FILE))
. $WORK_DIR/shell/common.sh
cd /
DEST_DIR=/vhs
stop_system
clean_system
rm -rf $DEST_DIR
