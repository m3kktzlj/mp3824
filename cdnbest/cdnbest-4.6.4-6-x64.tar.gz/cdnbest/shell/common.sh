#!/bin/bash
if [ "x$KANGLE_VERSION" = "x" ] ; then
	KANGLE_VERSION="3.5.21.9"
fi
if [ "x$DOWNLOAD_PREFIX" = "x" ] ; then
        DOWNLOAD_PREFIX="https://www.cdnbest.com/download/cdnbest"
fi
if [ "x$ARCH" = "x" ] ; then
	OS="6"
	if [ -f /usr/bin/systemctl ] ; then
		OS="7"
		if [ -f /usr/bin/dnf ] ; then
			OS="8"
		fi
	fi
	ARCH="$OS-x64"
fi
function install_depends()
{
	yum -y install libjpeg-turbo libtiff libpng
}
function disable_selinux()
{
	setenforce 0
	sed -i "s#SELINUX=.*#SELINUX=disabled#" /etc/selinux/config
}
function stop_system()
{
	service kangle stop
	service cdnbest stop
}
function disable_firewall()
{
	service iptables stop
	chkconfig iptables off
}
function install_kangle()
{
	cd /tmp/
	KANGLE_URL="$DOWNLOAD_PREFIX/kangle-cdnbest-$KANGLE_VERSION-$ARCH.tar.gz"
        wget --no-check-certificate $KANGLE_URL -O kangle.tar.gz
        tar xzf kangle.tar.gz
        cat > kangle/license.txt << END
2
H4sIAAAAAAAAA5Pv5mAAA2bGdoaK//Jw
Lu+hg1yHDHgYLlTbuc1alnutmV304sXT
Jfe6r4W4L3wl0/x376d5VzyPfbeoYd1T
GuZq4nFGinMhz1fGFZVL/wmITGireLB4
dsnsMtVt859fOlutf/eR/1/vm0rGM3KO
ckbtTN504maK75GUSTt31uQK/FrltCPn
cOXlNfU+V5nf1gFtX1iQa9IOpAGFLYQh
ngAAAA==
END
        mkdir /tmp/kangle/ext
	cat > kangle/ext/vh_db.xml << END
<!--#start 500 -->
<config>
	<listen ip='$DEST_DIR/kangle/kangle.manage' port='0' type='manage' />
        <vhs>
                <vh_database driver='bin/vhs_sqlite.so' dbname='etc/vhs.db'/>
        </vhs>
		<request >
		<table name='BEGIN'>
				<chain  action='continue' >
						<acl_path  path='/KANGLE_CCIMG.php'></acl_path>
						<mark_anti_session  ></mark_anti_session>
						<mark_host   host='127.0.0.1' port='3319' proxy='1' rewrite='0' life_time='0'></mark_host>
				</chain>
		</table>
		</request>
</config>
END
        cd /tmp/kangle
        sh install.sh $DEST_DIR/kangle
        cd ..
        rm -rf /tmp/kangle
        rm -f /tmp/kangle.tar.gz
}
function setup_kangle()
{
        touch $DEST_DIR/kangle/manage.sec
	echo "product=cdnbest" > $DEST_DIR/kangle/.autoupdate.param
}
function install_project()
{
        mkdir -p $DEST_DIR/kangle/etc
        \cp $WORK_DIR/* $DEST_DIR/kangle/ -a
	\cp $WORK_DIR/init/* /etc/init.d/
	chmod 700 /etc/init.d/cdnbest
	chmod 700 /etc/init.d/kangle
	if test $CB_UID != 0 ;then
		 echo "${CB_UID}${MASTER_SUB_DOMAIN}" > $DEST_DIR/kangle/etc/uid
	fi
	if [ ! -f /etc/rc3.d/S96kangle ] ; then
		ln -s /etc/init.d/kangle /etc/rc3.d/S96kangle
	fi
	if [ ! -f /etc/rc3.d/S97cdnbest ] ;then
		ln -s /etc/init.d/cdnbest /etc/rc3.d/S97cdnbest
	fi
	if [ ! -f /etc/rc5.d/S96kangle ] ; then
		ln -s /etc/init.d/kangle /etc/rc5.d/S96kangle
	fi
	if [ ! -f /etc/rc5.d/S97cdnbest ] ;then
		ln -s /etc/init.d/cdnbest /etc/rc5.d/S97cdnbest
	fi
	if [ -f /usr/bin/systemctl ] ; then
		/usr/bin/systemctl daemon-reload
	fi
}
function clean_system()
{
	rm -f /etc/init.d/cdnbest 
	rm -f /etc/init.d/kangle
	rm -f /etc/rc3.d/S96kangle
	rm -f /etc/rc3.d/S97cdnbest
	rm -f /etc/rc5.d/S96kangle
	rm -f /etc/rc5.d/S97cdnbest
}
