#!/bin/bash
BIN_FILE=$(readlink -f $0)
WORK_DIR=$(dirname $(dirname $BIN_FILE))
. $WORK_DIR/shell/common.sh
DEST_DIR=/vhs
stop_system
install_depends
install_kangle
\cp $WORK_DIR/* $DEST_DIR/kangle/ -a
\cp $WORK_DIR/init/* /etc/init.d/
service cdnbest start
